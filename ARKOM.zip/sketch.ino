#include <Wire.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

const int pinSakelarUtama = 2;
const int pinPintu        = 3;
const int pinJendela1     = 4;
const int pinJendela2     = 5;
const int pinReset        = 6;
const int pinPIR          = 7;

const int pinLEDHijau     = 10;
const int pinLEDKuning    = 11;
const int pinBuzzer       = 12;
const int pinLEDMerah     = 13;

bool statusAlarm = false;

String zona = "";

void setup()
{
  pinMode(pinSakelarUtama, INPUT_PULLUP);
  pinMode(pinPintu, INPUT_PULLUP);
  pinMode(pinJendela1, INPUT_PULLUP);
  pinMode(pinJendela2, INPUT_PULLUP);
  pinMode(pinReset, INPUT_PULLUP);

  pinMode(pinPIR, INPUT);

  pinMode(pinLEDHijau, OUTPUT);
  pinMode(pinLEDKuning, OUTPUT);
  pinMode(pinLEDMerah, OUTPUT);
  pinMode(pinBuzzer, OUTPUT);

  lcd.init();
  lcd.backlight();

  lcd.setCursor(0,0);
  lcd.print("SMART ALARM");
  lcd.setCursor(0,1);
  lcd.print("SYSTEM READY");

  delay(2000);
  lcd.clear();
}

void loop()
{

  bool sakelarAktif = (digitalRead(pinSakelarUtama) == LOW);

  bool pintuBuka =
      (digitalRead(pinPintu) == LOW);

  bool jendela1Buka =
      (digitalRead(pinJendela1) == LOW);

  bool jendela2Buka =
      (digitalRead(pinJendela2) == LOW);

  bool resetDitekan =
      (digitalRead(pinReset) == LOW);

  bool gerakanTerdeteksi =
      (digitalRead(pinPIR) == HIGH);


  if (sakelarAktif)
  {
    digitalWrite(pinLEDHijau, HIGH);
    digitalWrite(pinLEDKuning, LOW);
  }
  else
  {
    digitalWrite(pinLEDHijau, LOW);
    digitalWrite(pinLEDKuning, HIGH);
  }

  if (!statusAlarm)
  {
    lcd.setCursor(0,0);

    if (sakelarAktif)
    {
      lcd.print("SYSTEM ARMED  ");
    }
    else
    {
      lcd.print("SYSTEM OFF    ");
    }

    lcd.setCursor(0,1);
    lcd.print("MONITOR READY ");
  }

  if (pintuBuka)
  {
    zona = "PINTU";
  }

  if (jendela1Buka)
  {
    zona = "JENDELA 1";
  }

  if (jendela2Buka)
  {
    zona = "JENDELA 2";
  }

  if (gerakanTerdeteksi)
  {
    zona = "GERAKAN";
  }

  bool adaGangguan =
  (
    pintuBuka ||
    jendela1Buka ||
    jendela2Buka ||
    gerakanTerdeteksi
  );

  if (sakelarAktif && adaGangguan)
  {
    statusAlarm = true;
  }

  if (resetDitekan)
  {
    statusAlarm = false;

    digitalWrite(pinLEDMerah, LOW);
    noTone(pinBuzzer);

    lcd.clear();
    lcd.setCursor(0,0);
    lcd.print("ALARM RESET");
    delay(1000);
  }


  if (statusAlarm)
  {
    digitalWrite(pinLEDMerah, HIGH);

    tone(pinBuzzer, 1000);

    lcd.setCursor(0,0);
    lcd.print("ALARM AKTIF!  ");

    lcd.setCursor(0,1);
    lcd.print("ZONA:");
    lcd.print(zona);
    lcd.print("      ");
  }
  else
  {
    digitalWrite(pinLEDMerah, LOW);
    noTone(pinBuzzer);
  }

  delay(100);
}